import Model.Defs

/-!
# Solution to exercise 1: the statement

This is the part participants write, and the only part to compare with your
own. The proof is in `Proofs.lean` next to this file.
-/

namespace ModelSolution

open Model

/-- For every hash function, every list of leaves and every in-range index, `getProof`
succeeds and the proof verifies against the root for the leaf at that index. -/
def CompletenessStatement : Prop :=
  ∀ (H : HashFn) (leaves : List (List UInt8)) (i : Nat),
    (hi : i < leaves.length) →
    ∃ p : MerkleProof,
      (build H leaves).getProof i = .ok p ∧
      p.verifyProof H (build H leaves).root leaves[i] i = .ok ()

end ModelSolution
