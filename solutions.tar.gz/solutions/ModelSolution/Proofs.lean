import ModelSolution.Statements

/-!
# Solution to exercise 1: the proof

What the LLM produces for the statement in `Statements.lean`: an invariant over
the stored levels of the tree (`buildLevels_complete`) and the small facts
about padding, pairing and list indexing that it uses. Nobody is expected to
write this by hand.
-/

namespace ModelSolution

open Model

/-! ### Helper lemmas -/

theorem buildLevels_ne_nil (H : HashFn) (L : List Node) : buildLevels H L ≠ [] := by
  unfold buildLevels
  split <;> simp

theorem proofPath_cons (level : List Node) (rest : List (List Node)) (hrest : rest ≠ [])
    (i : Nat) :
    proofPath (level :: rest) i =
      level.getD (siblingIndex i) .empty :: proofPath rest (i / 2) := by
  cases rest with
  | nil => exact absurd rfl hrest
  | cons l rest => rfl

theorem length_padLevel (L : List Node) : (padLevel L).length % 2 = 0 := by
  unfold padLevel
  split
  · simp only [List.length_append, List.length_singleton]; omega
  · omega

theorem length_le_length_padLevel (L : List Node) : L.length ≤ (padLevel L).length := by
  unfold padLevel
  split <;> simp

theorem getD_padLevel (L : List Node) (i : Nat) (hi : i < L.length) :
    (padLevel L).getD i .empty = L.getD i .empty := by
  unfold padLevel
  split
  · rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_append_left hi]
  · rfl

theorem length_hashPairs (H : HashFn) (P : List Node) :
    (hashPairs H P).length = P.length / 2 := by
  simp [hashPairs]

theorem getD_hashPairs (H : HashFn) (P : List Node) (j : Nat) (hj : j < P.length / 2) :
    (hashPairs H P).getD j .empty =
      innerHash H (P.getD (2 * j) .empty) (P.getD (2 * j + 1) .empty) := by
  rw [List.getD_eq_getElem?_getD]
  simp [hashPairs, hj]

theorem flatten_buildLevels_ne_nil (H : HashFn) (L : List Node) (hL : L ≠ []) :
    (buildLevels H L).flatten ≠ [] := by
  unfold buildLevels
  split
  · simpa
  · simp only [List.flatten_cons, ne_eq, List.append_eq_nil_iff, not_and]
    intro h
    exact absurd h (by unfold padLevel; split <;> simp_all)

/-- The one-level step: climbing one sibling from position `i` of the padded level lands on
position `i / 2` of the next level. -/
theorem climb_step (H : HashFn) (P : List Node) (hP : P.length % 2 = 0) (i : Nat)
    (hi : i < P.length) :
    (if i % 2 = 0 then innerHash H (P.getD i .empty) (P.getD (siblingIndex i) .empty)
      else innerHash H (P.getD (siblingIndex i) .empty) (P.getD i .empty)) =
    (hashPairs H P).getD (i / 2) .empty := by
  rw [getD_hashPairs H P (i / 2) (by omega)]
  unfold siblingIndex
  split
  · have h1 : 2 * (i / 2) = i := by omega
    rw [h1]
  · have h1 : 2 * (i / 2) = i - 1 := by omega
    have h2 : i - 1 + 1 = i := by omega
    rw [h1, h2]

/-- Generalised completeness over the stored levels, together with the index bound that
`computeRoot` checks. -/
theorem buildLevels_complete (H : HashFn) (L : List Node) :
    ∀ i, i < L.length →
      climb H (proofPath (buildLevels H L) i) (L.getD i .empty) i =
          (buildLevels H L).flatten.getLast?.getD .empty ∧
      i < 2 ^ (proofPath (buildLevels H L) i).length := by
  induction L using buildLevels.induct H with
  | case1 L hL =>
    intro i hi
    have hi0 : i = 0 := by omega
    subst hi0
    obtain ⟨x, rfl⟩ : ∃ x, L = [x] := by
      match L, hL, hi with
      | [x], _, _ => exact ⟨x, rfl⟩
    rw [buildLevels]
    simp [proofPath, climb]
  | case2 L hL padded ih =>
    intro i hi
    rw [show padded = padLevel L from rfl] at ih
    clear padded
    have hP : (padLevel L).length % 2 = 0 := length_padLevel L
    have hiP : i < (padLevel L).length := Nat.lt_of_lt_of_le hi (length_le_length_padLevel L)
    have hnext : i / 2 < (hashPairs H (padLevel L)).length := by
      rw [length_hashPairs]; omega
    obtain ⟨ih1, ih2⟩ := ih (i / 2) hnext
    rw [buildLevels]
    simp only [hL, ↓reduceIte]
    rw [proofPath_cons _ _ (buildLevels_ne_nil H _)]
    simp only [climb, List.flatten_cons, List.length_cons]
    rw [← getD_padLevel L i hi, climb_step H (padLevel L) hP i hiP]
    refine ⟨?_, ?_⟩
    · rw [ih1, List.getLast?_append]
      have hne := flatten_buildLevels_ne_nil H (hashPairs H (padLevel L)) (by
        intro h
        have := congrArg List.length h
        rw [length_hashPairs] at this
        simp at this
        omega)
      rcases hflat : (buildLevels H (hashPairs H (padLevel L))).flatten with _ | ⟨a, as⟩
      · exact absurd hflat hne
      · simp [List.getLast?_cons]
    · rw [Nat.pow_succ]
      omega

/-! ### The theorem -/

theorem completeness : CompletenessStatement := by
  intro H leaves i hi
  have hlen : (leaves.map (leafHash H)).length = leaves.length := by simp
  obtain ⟨hclimb, hbound⟩ :=
    buildLevels_complete H (leaves.map (leafHash H)) i (by rw [hlen]; exact hi)
  refine ⟨{ path := proofPath (buildLevels H (leaves.map (leafHash H))) i }, ?_, ?_⟩
  · simp [build, buildFromLeafHashes, MerkleTree.getProof, hlen, Nat.not_le.mpr hi]
  · have hleaf : (leaves.map (leafHash H)).getD i .empty = leafHash H leaves[i] := by
      rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_eq_getElem hi]
      rfl
    have hshift : i >>> (proofPath (buildLevels H (leaves.map (leafHash H))) i).length = 0 := by
      rw [Nat.shiftRight_eq_div_pow]
      exact Nat.div_eq_of_lt hbound
    simp only [MerkleProof.verifyProof, MerkleProof.computeRoot, hshift, ne_eq,
      not_true_eq_false, ite_false, build, buildFromLeafHashes, MerkleTree.root, MerkleTree.nodes]
    rw [← hleaf, hclimb]
    simp

end ModelSolution
