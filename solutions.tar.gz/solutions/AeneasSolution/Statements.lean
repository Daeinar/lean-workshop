import FastcryptoMerkle.Spec.HashAdapter
open Aeneas Aeneas.Std Result
open FastcryptoMerkle FastcryptoMerkle.Spec

/-!
# Reference statements for the three exercises

These are the statements we expect participants to arrive at in
`exercises/FastcryptoMerkle/Statements.lean`. The matching reference proofs are
in `solutions/AeneasSolution/Proofs.lean`.

All three are stated directly about the Aeneas-extracted functions, with the
hash fixed to `Spec.hashFunction H` for an arbitrary `H`. See `PROJECT.md`
for why direct statements were chosen over a refinement to the executable
model.
-/

namespace AeneasSolution

/-! ## Exercise 1: the root of the empty tree

`build_root` of no leaves is `Node::Empty`. No hash is involved, so this is
the warm-up for the workflow: how to quantify over a `Slice`, what `ok` means,
how to say "no leaves" (`leaves.val = []`, not a literal, since `Slice` has a
length bound to discharge). -/

def EmptyRootStatement : Prop :=
  ∀ (H : HashSpec) (leaves : Slice (alloc.vec.Vec U8)),
    leaves.val = [] →
    build_root (hashFunction H) leaves = ok .Empty

/-! ## Exercise 2: `get_proof` on an out-of-bounds index fails

For any tree value and any index at or beyond `n_leaves`, `get_proof` returns
`Err`. The statement quantifies over *arbitrary* `MerkleTree` structures,
including ones no builder would produce, because the bounds check runs before
anything else. The converse, in-bounds implies `Ok`, is false for arbitrary
structures (inconsistent `nodes`/`n_leaves` make the indexing panic) and only
holds for honestly built trees; it is part of exercise 3. Participants should
discover that asymmetry. -/

def OutOfBoundsStatement : Prop :=
  ∀ (H : HashSpec) (tree : fastcrypto.merkle.MerkleTree HashState) (index : Usize),
    tree.n_leaves ≤ index →
    ∃ e, fastcrypto.merkle.MerkleTree.get_proof (hashFunction H) tree index = ok (.Err e)

/-! ## Exercise 3: prove-verify roundtrip

For every hash, every leaf list and every in-bounds index, building the tree,
generating the proof and verifying it against the root succeeds.

The size bound is not decoration. `compute_root` rejects any path with
`usize::BITS` or more siblings, and `n_nodes`, the level offsets and `Vec::push`
all do machine arithmetic that can overflow in the Aeneas model. Without a
bound the statement is false for leaf lists longer than about `2^63`. The
bound below is far from tight; the point of the exercise is that there has to
be one, and the LLM should say so if it is missing. -/

def RoundtripStatement : Prop :=
  ∀ (H : HashSpec) (leaves : Slice (alloc.vec.Vec U8)) (index : Usize),
    4 * leaves.val.length ≤ Usize.max →
    index.val < leaves.val.length →
    inclusion_roundtrip (hashFunction H) leaves index = ok true

end AeneasSolution
