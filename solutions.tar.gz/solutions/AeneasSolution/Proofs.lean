import FastcryptoMerkle.Spec.Loops
import AeneasSolution.Statements
open Aeneas Aeneas.Std Result
open FastcryptoMerkle FastcryptoMerkle.Spec AeneasSolution

/-!
# Reference proofs of the three exercises

What an LLM should produce from the prompt in the workshop README, given
`Spec/Loops.lean` and `Spec/Model.lean`.
-/

namespace AeneasSolution

theorem empty_root : EmptyRootStatement := by
  intro H leaves hl
  rw [← spec_eq_ok_iff]
  unfold build_root
  have h4 : 4 * leaves.val.length ≤ Usize.max := by rw [hl]; simp
  step*
  rw [r_post, mt_post, hl, List.map_nil, levels_of_le _ _ (by simp)]
  simp

theorem out_of_bounds : OutOfBoundsStatement := by
  intro H tree index hidx
  unfold fastcrypto.merkle.MerkleTree.get_proof
  rw [if_pos hidx]
  refine ⟨.GeneralError "", ?_⟩
  simp [core.fmt.rt.Argument.new_display, core.fmt.Arguments.new, alloc.fmt.format, core.hint.must_use]

theorem roundtrip : RoundtripStatement := by
  intro H leaves index hmax hidx
  rw [← spec_eq_ok_iff]
  unfold inclusion_roundtrip
  -- Facts about the level model for `L`, the hashed leaves.
  set L := leaves.val.map (leafDigest H) with hLdef
  have hLlen : L.length = leaves.val.length := by simp [hLdef]
  have hnb : 32 ≤ Usize.numBits := by
    rw [Usize.numBits_def, UScalarTy.Usize_numBits_eq]
    cases System.Platform.numBits_eq <;> omega
  have hmaxd : Usize.max = 2 ^ Usize.numBits - 1 := Usize.max_def
  have h4 : 2 ^ Usize.numBits = 2 ^ (Usize.numBits - 2) * 2 * 2 := by
    rw [← Nat.pow_succ, ← Nat.pow_succ]
    congr 1
    omega
  have hn : leaves.val.length ≤ 2 ^ (Usize.numBits - 2) := by omega
  have hlev := length_levels_le H (Usize.numBits - 2) L (by rw [hLlen]; exact hn)
  have hpow : Usize.numBits < 2 ^ Usize.numBits := Nat.lt_two_pow_self
  have hpp := length_proofPath (levels H L) (levels_ne_nil H L) index.val
  obtain ⟨hclimb, hbound⟩ := levels_complete H L index.val (by rw [hLlen]; exact hidx)
  step*
  case hlen =>
    have hp : p = proof := by
      obtain ⟨r, h1, h2⟩ : ∃ r, r = core.result.Result.Ok p ∧ r = core.result.Result.Ok proof :=
        ⟨_, by assumption, by assumption⟩
      rw [h1] at h2; exact core.result.Result.Ok.inj h2
    rw [← hp, r_post1, hpp]
    omega
  · rename_i hnone
    rw [o_post, List.getElem?_eq_getElem hidx] at hnone
    cases hnone
  · have hp : p = proof := by
      obtain ⟨r, h1, h2⟩ : ∃ r, r = core.result.Result.Ok p ∧ r = core.result.Result.Ok proof :=
        ⟨_, by assumption, by assumption⟩
      rw [h1] at h2; exact core.result.Result.Ok.inj h2
    have hleaf : leaf = leaves.val[index.val] := by
      have h1 : o = some leaf := by assumption
      rw [o_post, List.getElem?_eq_getElem hidx] at h1
      exact (Option.some.inj h1).symm
    have hld : leafDigestSlice H leaf.deref = L.getD index.val .Empty := by
      rw [hLdef, List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_eq_getElem hidx]
      simp [leafDigestSlice, leafDigest, alloc.vec.Vec.deref, hleaf]
    have hcl : climb H proof.path.val (leafDigestSlice H leaf.deref) index.val = n := by
      rw [← hp, r_post1, hld, hclimb, n_post, tree_post]
      rfl
    rw [r_post, r1_post hcl]
    rfl

end AeneasSolution
